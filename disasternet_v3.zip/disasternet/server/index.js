const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST', 'DELETE'] }
});

app.use(cors());
app.use(express.json());

// ─── Admin credentials (change these!) ─────────────────────
const ADMIN_USERNAME = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASS || 'disasternet123';
const ADMIN_TOKEN = crypto.createHash('sha256')
  .update(ADMIN_USERNAME + ADMIN_PASSWORD + 'disasternet-secret')
  .digest('hex');

// ─── Auth middleware ────────────────────────────────────────
function requireAdmin(req, res, next) {
  const token = req.headers['x-admin-token'];
  if (token === ADMIN_TOKEN) return next();
  res.status(401).json({ error: 'Unauthorized' });
}

// ─── Config ────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/disasternet';
const PEERS = process.env.PEERS ? process.env.PEERS.split(',') : [];
const NODE_ID = process.env.NODE_ID || 'node-' + Math.random().toString(36).slice(2, 8);

console.log(`[DisasterNet] Node ID: ${NODE_ID}`);
console.log(`[DisasterNet] Peers: ${PEERS.length > 0 ? PEERS.join(', ') : 'none (standalone mode)'}`);

// ─── MongoDB Schema ─────────────────────────────────────────
mongoose.connect(MONGO_URI).then(() => {
  console.log('[DisasterNet] MongoDB connected');
}).catch(err => {
  console.warn('[DisasterNet] MongoDB not available, using in-memory store');
});

const messageSchema = new mongoose.Schema({
  id: { type: String, unique: true, required: true },
  hash: { type: String, unique: true },
  content: String,
  category: { type: String, enum: ['medical', 'rescue', 'shelter', 'food', 'fire', 'flood', 'info', 'other'], default: 'info' },
  priority: { type: String, enum: ['critical', 'high', 'medium', 'low'], default: 'medium' },
  location: { lat: Number, lng: Number, name: String },
  sender: String,
  nodeId: String,
  ttl: { type: Number, default: 10 },
  hopCount: { type: Number, default: 0 },
  timestamp: { type: Date, default: Date.now, expires: 259200 } // 72hr TTL
});

const Message = mongoose.models.Message || mongoose.model('Message', messageSchema);

// ─── In-memory fallback store ───────────────────────────────
const memStore = [];
const seenHashes = new Set();

// ─── Helpers ────────────────────────────────────────────────
function hashMessage(content, sender, timestamp) {
  return crypto.createHash('sha256')
    .update(`${content}${sender}${timestamp}`)
    .digest('hex');
}

async function saveMessage(msg) {
  try {
    await Message.create(msg);
  } catch (e) {
    // fallback to memory
    if (!seenHashes.has(msg.hash)) {
      seenHashes.add(msg.hash);
      memStore.push(msg);
      if (memStore.length > 500) memStore.shift();
    }
  }
}

async function getMessages() {
  try {
    return await Message.find().sort({ timestamp: -1 }).limit(100).lean();
  } catch (e) {
    return [...memStore].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  }
}

// ─── Gossip: forward to peer nodes ─────────────────────────
async function gossipToPeers(msg) {
  if (msg.ttl <= 0) return;
  const forwardMsg = { ...msg, ttl: msg.ttl - 1, hopCount: msg.hopCount + 1 };

  for (const peer of PEERS) {
    try {
      const res = await fetch(`${peer}/api/messages/gossip`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(forwardMsg),
        signal: AbortSignal.timeout(3000)
      });
      if (res.ok) console.log(`[Gossip] Forwarded to ${peer}`);
    } catch (e) {
      console.warn(`[Gossip] Peer ${peer} unreachable`);
    }
  }
}

// ─── Routes ─────────────────────────────────────────────────

// Get all messages
app.get('/api/messages', async (req, res) => {
  const msgs = await getMessages();
  res.json(msgs);
});

// Post new message (from UI)
app.post('/api/messages', async (req, res) => {
  const { content, category, priority, location, sender } = req.body;
  if (!content || !content.trim()) return res.status(400).json({ error: 'Content required' });

  const timestamp = new Date().toISOString();
  const hash = hashMessage(content, sender || 'anonymous', timestamp);

  // Check for duplicate
  try {
    const existing = await Message.findOne({ hash });
    if (existing) return res.status(409).json({ error: 'Duplicate message' });
  } catch (e) {
    if (seenHashes.has(hash)) return res.status(409).json({ error: 'Duplicate message' });
  }

  const msg = {
    id: uuidv4(),
    hash,
    content: content.trim(),
    category: category || 'info',
    priority: priority || 'medium',
    location: location || {},
    sender: sender || 'Anonymous',
    nodeId: NODE_ID,
    ttl: 10,
    hopCount: 0,
    timestamp
  };

  await saveMessage(msg);
  io.emit('new_message', msg);
  gossipToPeers(msg);

  res.status(201).json(msg);
});

// Gossip endpoint (from peer nodes)
app.post('/api/messages/gossip', async (req, res) => {
  const msg = req.body;
  if (!msg || !msg.hash) return res.status(400).json({ error: 'Invalid message' });

  try {
    const existing = await Message.findOne({ hash: msg.hash });
    if (existing) return res.status(200).json({ status: 'already_seen' });
  } catch (e) {
    if (seenHashes.has(msg.hash)) return res.status(200).json({ status: 'already_seen' });
  }

  await saveMessage(msg);
  io.emit('new_message', msg);
  gossipToPeers(msg);

  res.status(201).json({ status: 'accepted' });
});

// Node info
app.get('/api/node', (req, res) => {
  res.json({ nodeId: NODE_ID, peers: PEERS, uptime: process.uptime() });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'online', nodeId: NODE_ID, timestamp: new Date().toISOString() });
});

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    res.json({ token: ADMIN_TOKEN, username });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

// Admin delete message
app.delete('/api/messages/:id', requireAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    await Message.findOneAndDelete({ id });
  } catch (e) {
    const idx = memStore.findIndex(m => m.id === id);
    if (idx !== -1) memStore.splice(idx, 1);
  }
  // Notify all clients to remove this message
  io.emit('message_deleted', { id });
  res.json({ success: true });
});

// ─── Socket.IO ──────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[Socket] Client connected: ${socket.id}`);

  socket.on('disconnect', () => {
    console.log(`[Socket] Client disconnected: ${socket.id}`);
  });
});

// ─── Peer sync every 30s ────────────────────────────────────
setInterval(async () => {
  if (PEERS.length === 0) return;
  console.log('[Sync] Running peer sync...');
  const msgs = await getMessages();
  for (const peer of PEERS) {
    for (const msg of msgs.slice(0, 20)) {
      try {
        await fetch(`${peer}/api/messages/gossip`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...msg, ttl: 1 }),
          signal: AbortSignal.timeout(2000)
        });
      } catch (e) { /* peer offline */ }
    }
  }
}, 30000);

// ─── Serve React build for other devices ──────────────────
const buildPath = path.join(__dirname, '../client/build');
app.use(express.static(buildPath));
app.get('/*', (req, res) => {
  const index = path.join(buildPath, 'index.html');
  res.sendFile(index, err => {
    if (err) res.status(200).send('DisasterNet running. Dev client on :3000');
  });
});

// ─── Start ──────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[DisasterNet] Server running on port ${PORT}`);
  const localIP = getLocalIP();
  console.log(`[DisasterNet] Local:   http://localhost:${PORT}`);
  console.log(`[DisasterNet] Network: http://${localIP}:${PORT}  ← open this on other devices`);
});
// show local IP for other devices
const { networkInterfaces } = require('os');
function getLocalIP() {
  const nets = networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) return net.address;
    }
  }
  return 'unknown';
}
