import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import AlertFeed from './components/AlertFeed';
import BroadcastComposer from './components/BroadcastComposer';
import OfflineMap from './components/OfflineMap';
import NetworkPanel from './components/NetworkPanel';
import AdminLogin from './components/AdminLogin';
import { useMessages, useNodeInfo } from './hooks/useDisasterNet';

export default function App() {
  const [activeTab, setActiveTab] = useState('feed');
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminToken, setAdminToken] = useState(() => sessionStorage.getItem('dn_admin_token') || '');
  const [adminUser, setAdminUser] = useState(() => sessionStorage.getItem('dn_admin_user') || '');

  const { messages, loading, connected, sendMessage, adminDelete, offlineQueue } = useMessages();
  const nodeInfo = useNodeInfo();

  const isAdmin = !!adminToken;

  const handleAdminLogin = (token, username) => {
    sessionStorage.setItem('dn_admin_token', token);
    sessionStorage.setItem('dn_admin_user', username);
    setAdminToken(token);
    setAdminUser(username);
    setShowAdminLogin(false);
  };

  const handleAdminLogout = () => {
    sessionStorage.removeItem('dn_admin_token');
    sessionStorage.removeItem('dn_admin_user');
    setAdminToken('');
    setAdminUser('');
  };

  const handleDelete = (id) => adminDelete(id, adminToken);

  // Secret: triple-click logo area to open admin login
  const [logoClicks, setLogoClicks] = useState(0);
  const handleLogoArea = () => {
    const next = logoClicks + 1;
    setLogoClicks(next);
    if (next >= 3) { setShowAdminLogin(true); setLogoClicks(0); }
    setTimeout(() => setLogoClicks(0), 1500);
  };

  if (showAdminLogin && !isAdmin) {
    return (
      <div onClick={e => { if (e.target === e.currentTarget) setShowAdminLogin(false); }}>
        <AdminLogin onLogin={handleAdminLogin} />
        <button
          onClick={() => setShowAdminLogin(false)}
          style={{
            position: 'fixed', top: 20, right: 20, zIndex: 999,
            background: 'var(--bg3)', border: '1px solid var(--border)',
            borderRadius: 3, padding: '6px 12px', color: 'var(--text-muted)',
            fontSize: 11, cursor: 'pointer', fontFamily: 'var(--font-mono)'
          }}>
          ← BACK
        </button>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: 'var(--bg)' }}>
      <div onClick={handleLogoArea}>
        <Header
          connected={connected}
          nodeInfo={nodeInfo}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isAdmin={isAdmin}
          adminUser={adminUser}
          onAdminLogout={handleAdminLogout}
        />
      </div>

      {/* Admin login button (bottom right) */}
      {!isAdmin && (
        <button
          onClick={() => setShowAdminLogin(true)}
          style={{
            position: 'fixed', bottom: 16, right: 16, zIndex: 50,
            background: 'var(--bg3)', border: '1px solid var(--border)',
            borderRadius: 3, padding: '7px 12px',
            color: 'var(--text-muted)', fontSize: 10, letterSpacing: 1,
            cursor: 'pointer', fontFamily: 'var(--font-mono)'
          }}>
          🛡 ADMIN
        </button>
      )}

      <main style={{ flex: 1, overflow: 'hidden' }}>
        {activeTab === 'feed' && (
          <AlertFeed
            messages={messages}
            loading={loading}
            isAdmin={isAdmin}
            onDelete={handleDelete}
            offlineQueue={offlineQueue}
          />
        )}
        {activeTab === 'broadcast' && (
          <BroadcastComposer sendMessage={sendMessage} connected={connected} />
        )}
        {activeTab === 'map' && (
          <OfflineMap messages={messages} />
        )}
        {activeTab === 'network' && (
          <NetworkPanel nodeInfo={nodeInfo} connected={connected} messages={messages} />
        )}
      </main>
    </div>
  );
}
