import { useEffect, useRef, useState, useCallback } from 'react';
import { io } from 'socket.io-client';
import axios from 'axios';

// Detect server URL — works for localhost AND other devices on same Wi-Fi
function getServerURL() {
  const hostname = window.location.hostname;
  // If opened via IP (e.g. another device), connect to same IP on port 5000
  if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
    return `http://${hostname}:5000`;
  }
  return 'http://localhost:5000';
}

const SERVER = getServerURL();
console.log('[DisasterNet] Connecting to server:', SERVER);

// ── Alert beep using Web Audio API ──────────────────────────
export function playAlertBeep(priority = 'medium') {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const configs = {
      critical: [{ freq: 880, dur: 0.15 }, { freq: 660, dur: 0.15 }, { freq: 880, dur: 0.3 }],
      high:     [{ freq: 660, dur: 0.15 }, { freq: 880, dur: 0.25 }],
      medium:   [{ freq: 520, dur: 0.2 }],
      low:      [{ freq: 400, dur: 0.15 }],
    };
    const tones = configs[priority] || configs.medium;
    let time = ctx.currentTime;
    tones.forEach(({ freq, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = freq;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.4, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + dur);
      osc.start(time);
      osc.stop(time + dur);
      time += dur + 0.05;
    });
  } catch (e) { /* audio blocked */ }
}

// ── useSocket ────────────────────────────────────────────────
export function useSocket(onMessage, onDelete) {
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const socket = io(SERVER, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: Infinity,
    });
    socketRef.current = socket;

    socket.on('connect', () => { console.log('[Socket] Connected'); setConnected(true); });
    socket.on('disconnect', () => { console.log('[Socket] Disconnected'); setConnected(false); });
    socket.on('connect_error', () => setConnected(false));
    socket.on('new_message', (msg) => { if (onMessage) onMessage(msg); });
    socket.on('message_deleted', ({ id }) => { if (onDelete) onDelete(id); });

    return () => socket.disconnect();
  }, []);

  return { connected };
}

// ── Offline queue ────────────────────────────────────────────
const OFFLINE_QUEUE_KEY = 'dn_offline_queue';
function loadOfflineQueue() {
  try { return JSON.parse(localStorage.getItem(OFFLINE_QUEUE_KEY) || '[]'); }
  catch { return []; }
}
function saveOfflineQueue(q) {
  localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(q));
}

// ── useMessages ──────────────────────────────────────────────
export function useMessages() {
  const [messages, setMessages] = useState(() => {
    try { return JSON.parse(localStorage.getItem('dn_messages') || '[]'); }
    catch { return []; }
  });
  const [loading, setLoading] = useState(true);
  const [offlineQueue, setOfflineQueue] = useState(loadOfflineQueue);

  const addMessage = useCallback((msg) => {
    setMessages(prev => {
      // Dedup by id OR hash
      if (prev.find(m =>
        (m.id && msg.id && m.id === msg.id) ||
        (m.hash && msg.hash && m.hash === msg.hash)
      )) return prev;
      const next = [msg, ...prev].slice(0, 200);
      try { localStorage.setItem('dn_messages', JSON.stringify(next)); } catch(e) {}
      return next;
    });
    playAlertBeep(msg.priority);
    if (document.hidden && Notification.permission === 'granted') {
      new Notification(`DisasterNet — ${msg.priority?.toUpperCase()} ALERT`, {
        body: msg.content, icon: '/favicon.ico', tag: msg.id,
      });
    }
  }, []);

  // ── FIX: delete only the specific message by id ──────────
  const deleteMessage = useCallback((id) => {
    if (!id) return;
    setMessages(prev => {
      // Match by id field (custom uuid) — NOT _id (MongoDB)
      const next = prev.filter(m => {
        const msgId = m.id || m._id;
        return String(msgId) !== String(id);
      });
      try { localStorage.setItem('dn_messages', JSON.stringify(next)); } catch(e) {}
      return next;
    });
  }, []);

  const { connected } = useSocket(addMessage, deleteMessage);

  useEffect(() => {
    if (Notification.permission === 'default') Notification.requestPermission();
  }, []);

  // Load from server on mount
  useEffect(() => {
    axios.get(`${SERVER}/api/messages`)
      .then(r => {
        setMessages(r.data);
        try { localStorage.setItem('dn_messages', JSON.stringify(r.data)); } catch(e) {}
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  // Flush offline queue when back online
  useEffect(() => {
    if (!connected || offlineQueue.length === 0) return;
    (async () => {
      const queue = [...offlineQueue];
      setOfflineQueue([]);
      saveOfflineQueue([]);
      for (const item of queue) {
        try { await axios.post(`${SERVER}/api/messages`, item); }
        catch (e) { console.warn('Failed to flush queued message', e); }
      }
    })();
  }, [connected]);

  const sendMessage = useCallback(async (data) => {
    if (!connected) {
      const queued = { ...data, _queued: true, _queuedAt: new Date().toISOString() };
      const q = [...loadOfflineQueue(), queued];
      saveOfflineQueue(q);
      setOfflineQueue(q);
      throw new Error('OFFLINE_QUEUED');
    }
    const res = await axios.post(`${SERVER}/api/messages`, data);
    return res.data;
  }, [connected]);

  const adminDelete = useCallback(async (id, token) => {
    if (!id) throw new Error('No message ID');
    await axios.delete(`${SERVER}/api/messages/${id}`, {
      headers: { 'x-admin-token': token }
    });
    deleteMessage(id);
  }, [deleteMessage]);

  return { messages, loading, connected, sendMessage, adminDelete, offlineQueue: offlineQueue.length };
}

// ── useNodeInfo ──────────────────────────────────────────────
export function useNodeInfo() {
  const [nodeInfo, setNodeInfo] = useState(null);
  useEffect(() => {
    const doFetch = () => {
      axios.get(`${SERVER}/api/node`)
        .then(r => setNodeInfo(r.data))
        .catch(() => setNodeInfo({ nodeId: 'standalone', peers: [] }));
    };
    doFetch();
    const t = setInterval(doFetch, 10000);
    return () => clearInterval(t);
  }, []);
  return nodeInfo;
}
