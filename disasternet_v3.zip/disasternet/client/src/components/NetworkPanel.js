import React from 'react';

export default function NetworkPanel({ nodeInfo, connected, messages }) {
  const uptime = nodeInfo?.uptime
    ? `${Math.floor(nodeInfo.uptime / 3600)}h ${Math.floor((nodeInfo.uptime % 3600) / 60)}m`
    : '—';

  const stats = [
    { label: 'Node ID', value: nodeInfo?.nodeId || '—' },
    { label: 'Status', value: connected ? 'ONLINE' : 'OFFLINE', color: connected ? 'var(--green)' : 'var(--red)' },
    { label: 'Peer nodes', value: nodeInfo?.peers?.length || 0 },
    { label: 'Uptime', value: uptime },
    { label: 'Messages cached', value: messages.length },
    { label: 'Critical alerts', value: messages.filter(m => m.priority === 'critical').length, color: 'var(--red)' },
  ];

  return (
    <div style={{ padding: 16, height: '100%', overflowY: 'auto' }}>
      {/* Node stats */}
      <div style={{ marginBottom: 16, fontSize: 10, color: 'var(--text-muted)', letterSpacing: 2 }}>
        NODE STATUS
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 20 }}>
        {stats.map(s => (
          <div key={s.label} style={{
            background: 'var(--bg3)', border: '1px solid var(--border)',
            borderRadius: 3, padding: '10px 12px'
          }}>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', letterSpacing: 1, marginBottom: 4 }}>
              {s.label.toUpperCase()}
            </div>
            <div style={{ fontSize: 14, fontWeight: 700, color: s.color || 'var(--text)' }}>
              {String(s.value)}
            </div>
          </div>
        ))}
      </div>

      {/* Peer list */}
      <div style={{ marginBottom: 12, fontSize: 10, color: 'var(--text-muted)', letterSpacing: 2 }}>
        PEER NODES ({nodeInfo?.peers?.length || 0})
      </div>
      {(nodeInfo?.peers?.length || 0) === 0 ? (
        <div style={{
          background: 'var(--bg3)', border: '1px solid var(--border)',
          borderRadius: 3, padding: 14, marginBottom: 20
        }}>
          <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 6 }}>No peer nodes configured</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', lineHeight: 1.8 }}>
            To add peer nodes, set the PEERS environment variable:<br />
            <code style={{ color: 'var(--teal)', fontSize: 10 }}>
              PEERS=http://192.168.1.5:5000,http://192.168.1.6:5000 node index.js
            </code>
          </div>
        </div>
      ) : (
        nodeInfo.peers.map((peer, i) => (
          <div key={i} style={{
            background: 'var(--bg3)', border: '1px solid var(--border)',
            borderRadius: 3, padding: '8px 12px', marginBottom: 6,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between'
          }}>
            <span style={{ fontSize: 11, color: 'var(--text-dim)', fontFamily: 'var(--font-mono)' }}>{peer}</span>
            <span style={{ fontSize: 9, padding: '2px 6px', borderRadius: 2,
              background: 'rgba(0,230,118,0.1)', color: 'var(--green)', border: '1px solid rgba(0,230,118,0.3)' }}>
              PEER
            </span>
          </div>
        ))
      )}

      {/* How it works */}
      <div style={{ marginTop: 20, marginBottom: 12, fontSize: 10, color: 'var(--text-muted)', letterSpacing: 2 }}>
        HOW DISASTERNET WORKS
      </div>
      {[
        { icon: '📱', title: 'Mesh node', desc: 'Each phone running this app becomes a node. Connect devices to a shared Wi-Fi hotspot.' },
        { icon: '🔄', title: 'Gossip protocol', desc: 'Messages hop device-to-device with TTL=10. Each node forwards to all known peers.' },
        { icon: '💾', title: 'Store & forward', desc: 'Messages cached for 72 hours. New nodes sync automatically when they join the mesh.' },
        { icon: '🔏', title: 'Deduplication', desc: 'SHA-256 hash ensures each message is stored and forwarded exactly once.' },
        { icon: '🤖', title: 'AI triage', desc: 'On-device keyword AI classifies priority. No cloud, no API key, zero latency.' },
      ].map(item => (
        <div key={item.title} style={{
          display: 'flex', gap: 12, padding: '10px 0',
          borderBottom: '1px solid var(--border)'
        }}>
          <span style={{ fontSize: 18 }}>{item.icon}</span>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text)', marginBottom: 2 }}>{item.title}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', lineHeight: 1.6 }}>{item.desc}</div>
          </div>
        </div>
      ))}

      {/* Tech stack */}
      <div style={{ marginTop: 20, marginBottom: 10, fontSize: 10, color: 'var(--text-muted)', letterSpacing: 2 }}>
        TECH STACK
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {['Node.js', 'Express', 'Socket.IO', 'MongoDB', 'React', 'Leaflet', 'PWA'].map(t => (
          <span key={t} style={{
            padding: '3px 8px', fontSize: 10, borderRadius: 2,
            background: 'rgba(41,121,255,0.1)', color: 'var(--blue)',
            border: '1px solid rgba(41,121,255,0.3)'
          }}>{t}</span>
        ))}
      </div>
    </div>
  );
}
