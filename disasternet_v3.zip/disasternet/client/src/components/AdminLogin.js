import React, { useState } from 'react';
import axios from 'axios';

const SERVER = 'http://localhost:5000';

export default function AdminLogin({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPass, setShowPass] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!username || !password) { setError('Enter username and password'); return; }
    setLoading(true);
    setError('');
    try {
      const res = await axios.post(`${SERVER}/api/admin/login`, { username, password });
      onLogin(res.data.token, res.data.username);
    } catch (err) {
      setError('Invalid credentials. Try admin / disasternet123');
    }
    setLoading(false);
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)', padding: 20
    }}>
      {/* Background grid effect */}
      <div style={{
        position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none',
        backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)',
        backgroundSize: '40px 40px', opacity: 0.3
      }} />

      <div style={{
        position: 'relative', zIndex: 1,
        width: '100%', maxWidth: 380,
        background: 'var(--bg2)',
        border: '1px solid var(--border)',
        borderRadius: 6, overflow: 'hidden'
      }}>
        {/* Top red bar */}
        <div style={{ height: 3, background: 'var(--red)' }} />

        <div style={{ padding: '28px 28px 32px' }}>
          {/* Logo */}
          <div style={{ textAlign: 'center', marginBottom: 28 }}>
            <div style={{ fontSize: 11, letterSpacing: 4, color: 'var(--text-muted)', marginBottom: 8 }}>
              DISASTERNET
            </div>
            <div style={{
              fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 800,
              color: 'var(--text)', letterSpacing: 1
            }}>
              ADMIN <span style={{ color: 'var(--red)' }}>PORTAL</span>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
              Authorized personnel only
            </div>
          </div>

          {/* Warning box */}
          <div style={{
            background: 'rgba(255,140,0,0.08)', border: '1px solid rgba(255,140,0,0.25)',
            borderRadius: 3, padding: '8px 12px', marginBottom: 20,
            fontSize: 11, color: 'var(--amber)', lineHeight: 1.6
          }}>
            ⚠ Admin access allows deleting alerts from the mesh network.
          </div>

          <form onSubmit={handleLogin}>
            {/* Username */}
            <label style={labelStyle}>USERNAME</label>
            <input
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="admin"
              autoComplete="username"
              style={inputStyle}
            />

            {/* Password */}
            <label style={labelStyle}>PASSWORD</label>
            <div style={{ position: 'relative', marginBottom: 16 }}>
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••••••"
                autoComplete="current-password"
                style={{ ...inputStyle, marginBottom: 0, paddingRight: 40 }}
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                style={{
                  position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)',
                  background: 'none', border: 'none', color: 'var(--text-muted)',
                  cursor: 'pointer', fontSize: 14, padding: 0
                }}
              >{showPass ? '🙈' : '👁️'}</button>
            </div>

            {/* Error */}
            {error && (
              <div style={{
                background: 'rgba(255,59,59,0.1)', border: '1px solid rgba(255,59,59,0.3)',
                borderRadius: 3, padding: '8px 12px', marginBottom: 14,
                fontSize: 11, color: 'var(--red)'
              }}>⚠ {error}</div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              style={{
                width: '100%', padding: '11px',
                background: loading ? 'rgba(255,59,59,0.08)' : 'rgba(255,59,59,0.15)',
                border: '1px solid rgba(255,59,59,0.5)',
                borderRadius: 3, color: 'var(--red)',
                fontSize: 11, fontWeight: 700, letterSpacing: 2,
                cursor: loading ? 'wait' : 'pointer',
                fontFamily: 'var(--font-mono)', transition: 'all 0.2s'
              }}
            >
              {loading ? 'AUTHENTICATING...' : '▶ ACCESS ADMIN PANEL'}
            </button>
          </form>

          <div style={{ marginTop: 16, fontSize: 10, color: 'var(--text-muted)', textAlign: 'center' }}>
            Default: admin / disasternet123
          </div>
        </div>
      </div>
    </div>
  );
}

const labelStyle = {
  display: 'block', fontSize: 10, color: 'var(--text-muted)',
  letterSpacing: 1.5, marginBottom: 5
};

const inputStyle = {
  width: '100%', background: 'var(--bg3)',
  border: '1px solid var(--border)', borderRadius: 3,
  padding: '9px 12px', color: 'var(--text)',
  fontFamily: 'var(--font-mono)', fontSize: 13,
  outline: 'none', marginBottom: 14, display: 'block',
  transition: 'border-color 0.15s'
};
