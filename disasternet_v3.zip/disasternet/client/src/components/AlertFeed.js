import React, { useState } from 'react';
import { sortByPriority, timeAgo, PRIORITY_COLORS, CATEGORY_ICONS } from '../utils/helpers';

const PRIORITY_LABELS = { critical: 'CRITICAL', high: 'HIGH', medium: 'MED', low: 'LOW' };

function MessageCard({ msg, isAdmin, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const color = PRIORITY_COLORS[msg.priority] || '#888';

  const handleDelete = async (e) => {
    e.stopPropagation();
    if (!window.confirm(`Delete this alert?\n\n"${msg.content}"`)) return;
    setDeleting(true);
    try { await onDelete(msg.id); }
    catch { setDeleting(false); alert('Failed to delete.'); }
  };

  return (
    <div
      className={`animate-in bg-${msg.priority}`}
      onClick={() => setExpanded(!expanded)}
      style={{
        border: '1px solid transparent', borderRadius: 4,
        padding: '12px 14px', cursor: 'pointer', marginBottom: 6,
        transition: 'all 0.15s', position: 'relative',
        overflow: 'hidden', opacity: deleting ? 0.4 : 1
      }}
    >
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: color }} />
      <div style={{ paddingLeft: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ padding: '1px 6px', fontSize: 9, fontWeight: 700, letterSpacing: 1.5, border: `1px solid ${color}`, color, borderRadius: 2 }}>
              {PRIORITY_LABELS[msg.priority]}
            </span>
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
              {CATEGORY_ICONS[msg.category]} {msg.category?.toUpperCase()}
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{timeAgo(msg.timestamp)}</span>
            {isAdmin && (
              <button onClick={handleDelete} disabled={deleting}
                style={{
                  background: 'rgba(255,59,59,0.1)', border: '1px solid rgba(255,59,59,0.3)',
                  borderRadius: 2, padding: '2px 7px', color: 'var(--red)',
                  fontSize: 10, cursor: 'pointer', fontFamily: 'var(--font-mono)'
                }}>
                ✕ DEL
              </button>
            )}
          </div>
        </div>
        <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.5, marginBottom: 6 }}>{msg.content}</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>
            from <span style={{ color: 'var(--text-dim)' }}>{msg.sender}</span>
          </span>
          {expanded && (
            <div style={{ fontSize: 10, color: 'var(--text-muted)', textAlign: 'right' }}>
              <div>node: {msg.nodeId}</div>
              <div>hops: {msg.hopCount || 0} | ttl: {msg.ttl}</div>
              {msg.location?.name && <div>📍 {msg.location.name}</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function AlertFeed({ messages, loading, isAdmin, onDelete, offlineQueue }) {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const filtered = sortByPriority(messages).filter(m => {
    if (filter !== 'all' && m.priority !== filter && m.category !== filter) return false;
    if (search && !m.content.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const criticalCount = messages.filter(m => m.priority === 'critical').length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {criticalCount > 0 && (
        <div style={{
          background: 'rgba(255,59,59,0.12)', border: '1px solid rgba(255,59,59,0.3)',
          borderRadius: 4, padding: '8px 14px', margin: '12px 16px 0',
          display: 'flex', alignItems: 'center', gap: 8,
          animation: 'blink 2s ease-in-out infinite'
        }}>
          <span style={{ color: 'var(--red)', fontSize: 10, fontWeight: 700, letterSpacing: 2 }}>
            ⚠ {criticalCount} CRITICAL ALERT{criticalCount > 1 ? 'S' : ''} ACTIVE
          </span>
        </div>
      )}

      {offlineQueue > 0 && (
        <div style={{
          background: 'rgba(255,170,0,0.1)', border: '1px solid rgba(255,170,0,0.3)',
          borderRadius: 4, padding: '7px 14px', margin: '8px 16px 0',
          fontSize: 11, color: 'var(--amber)'
        }}>
          ⏳ {offlineQueue} message{offlineQueue > 1 ? 's' : ''} queued — will send when connection restores
        </div>
      )}

      {isAdmin && (
        <div style={{
          background: 'rgba(41,121,255,0.08)', border: '1px solid rgba(41,121,255,0.25)',
          borderRadius: 4, padding: '7px 14px', margin: '8px 16px 0',
          fontSize: 11, color: 'var(--blue)'
        }}>
          🛡 Admin mode — click DEL on any alert to remove it from the mesh
        </div>
      )}

      <div style={{ padding: '12px 16px', display: 'flex', gap: 8 }}>
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search alerts..."
          style={{ flex: 1, background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 3, padding: '6px 10px', color: 'var(--text)', fontFamily: 'var(--font-mono)', fontSize: 12, outline: 'none' }}
        />
        <select value={filter} onChange={e => setFilter(e.target.value)}
          style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 3, padding: '6px 8px', color: 'var(--text)', fontFamily: 'var(--font-mono)', fontSize: 11, outline: 'none', cursor: 'pointer' }}>
          <option value="all">ALL</option>
          <option value="critical">CRITICAL</option>
          <option value="high">HIGH</option>
          <option value="medical">MEDICAL</option>
          <option value="rescue">RESCUE</option>
          <option value="flood">FLOOD</option>
          <option value="fire">FIRE</option>
        </select>
      </div>

      <div style={{ padding: '0 16px 8px', fontSize: 10, color: 'var(--text-muted)', letterSpacing: 1 }}>
        {filtered.length} ALERT{filtered.length !== 1 ? 'S' : ''} · SORTED BY PRIORITY
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 16px' }}>
        {loading ? (
          <div style={{ color: 'var(--text-muted)', textAlign: 'center', padding: 40 }}>SCANNING MESH...</div>
        ) : filtered.length === 0 ? (
          <div style={{ color: 'var(--text-muted)', textAlign: 'center', padding: 40 }}>
            <div style={{ fontSize: 24, marginBottom: 8 }}>📡</div>
            <div>No alerts on mesh</div>
            <div style={{ fontSize: 11, marginTop: 4 }}>Network is clear</div>
          </div>
        ) : (
          filtered.map(msg => (
            <MessageCard key={msg.id || msg.hash} msg={msg} isAdmin={isAdmin} onDelete={onDelete} />
          ))
        )}
      </div>
    </div>
  );
}
