import React from 'react';

export default function Header({ connected, nodeInfo, activeTab, setActiveTab, isAdmin, adminUser, onAdminLogout }) {
  const tabs = [
    { id: 'feed', label: 'ALERT FEED' },
    { id: 'broadcast', label: 'BROADCAST' },
    { id: 'map', label: 'MAP' },
    { id: 'network', label: 'NETWORK' },
  ];

  return (
    <header style={{ background: 'var(--bg2)', borderBottom: '1px solid var(--border)', position: 'relative', zIndex: 100 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 20px', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ position: 'relative' }}>
            <div style={{
              width: 10, height: 10, borderRadius: '50%',
              background: connected ? 'var(--green)' : 'var(--red)',
              boxShadow: connected ? '0 0 8px var(--green)' : '0 0 8px var(--red)'
            }} />
            {connected && (
              <div style={{
                position: 'absolute', top: 0, left: 0, width: 10, height: 10,
                borderRadius: '50%', background: 'var(--green)', opacity: 0.4,
                animation: 'pulse-ring 1.5s ease-out infinite'
              }} />
            )}
          </div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, letterSpacing: 2 }}>
            DISASTER<span style={{ color: 'var(--red)' }}>NET</span>
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {isAdmin ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{
                padding: '3px 10px', borderRadius: 2, fontSize: 10, letterSpacing: 1, fontWeight: 700,
                background: 'rgba(41,121,255,0.1)', border: '1px solid rgba(41,121,255,0.4)', color: 'var(--blue)'
              }}>🛡 {adminUser?.toUpperCase()}</span>
              <button onClick={onAdminLogout} style={{
                background: 'none', border: '1px solid var(--border)', borderRadius: 2,
                padding: '3px 8px', color: 'var(--text-muted)', fontSize: 10,
                cursor: 'pointer', fontFamily: 'var(--font-mono)'
              }}>LOGOUT</button>
            </div>
          ) : (
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 9, color: 'var(--text-muted)', letterSpacing: 1 }}>NODE</div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>{nodeInfo?.nodeId || '—'}</div>
            </div>
          )}
          <div style={{
            padding: '3px 10px', borderRadius: 2,
            border: `1px solid ${connected ? 'rgba(0,230,118,0.4)' : 'rgba(255,59,59,0.4)'}`,
            background: connected ? 'rgba(0,230,118,0.08)' : 'rgba(255,59,59,0.08)',
            color: connected ? 'var(--green)' : 'var(--red)',
            fontSize: 10, letterSpacing: 2, fontWeight: 700
          }}>
            {connected ? '● MESH LIVE' : '○ OFFLINE'}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex' }}>
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
            flex: 1, padding: '10px 0', background: 'transparent', border: 'none',
            borderBottom: activeTab === tab.id ? '2px solid var(--red)' : '2px solid transparent',
            color: activeTab === tab.id ? 'var(--text)' : 'var(--text-muted)',
            fontSize: 10, letterSpacing: 2, fontWeight: 700, cursor: 'pointer',
            transition: 'all 0.15s', fontFamily: 'var(--font-mono)'
          }}>
            {tab.label}
          </button>
        ))}
      </div>
    </header>
  );
}
