import React, { useState, useEffect, useRef } from 'react';
import { autoClassifyPriority, autoClassifyCategory, CATEGORIES, PRIORITIES, CATEGORY_ICONS } from '../utils/helpers';

export default function BroadcastComposer({ sendMessage, connected }) {
  const [content, setContent] = useState('');
  const [sender, setSender] = useState(() => localStorage.getItem('dn_sender') || '');
  const [category, setCategory] = useState('info');
  const [priority, setPriority] = useState('medium');
  const [autoMode, setAutoMode] = useState(true);
  const [location, setLocation] = useState({ name: '', lat: null, lng: null });
  const [gpsStatus, setGpsStatus] = useState('idle'); // idle | loading | success | error
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const debounceRef = useRef(null);

  useEffect(() => {
    if (!autoMode || !content.trim()) return;
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setPriority(autoClassifyPriority(content));
      setCategory(autoClassifyCategory(content));
    }, 600);
    return () => clearTimeout(debounceRef.current);
  }, [content, autoMode]);

  // ── GPS fix: proper error handling + status feedback ──────
  const getLocation = () => {
    if (!navigator.geolocation) {
      setGpsStatus('error');
      setError('GPS not available on this device.');
      return;
    }
    setGpsStatus('loading');
    setError('');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          name: location.name || 'Current location',
        });
        setGpsStatus('success');
      },
      (err) => {
        setGpsStatus('error');
        if (err.code === 1) {
          setError('Location permission denied. Please allow location access in your browser settings.');
        } else if (err.code === 2) {
          setError('Location unavailable. Make sure Location Services is ON in System Settings → Privacy.');
        } else {
          setError('GPS timed out. Try again or enter location manually.');
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const clearLocation = () => {
    setLocation({ name: '', lat: null, lng: null });
    setGpsStatus('idle');
  };

  const handleSend = async () => {
    if (!content.trim()) { setError('Message cannot be empty'); return; }
    if (!sender.trim()) { setError('Please enter your name'); return; }
    setError('');
    setSending(true);
    try {
      localStorage.setItem('dn_sender', sender);
      await sendMessage({ content: content.trim(), category, priority, sender: sender.trim(), location });
      setContent('');
      setSent(true);
      setTimeout(() => setSent(false), 3000);
    } catch (e) {
      if (e.message === 'OFFLINE_QUEUED') {
        setContent('');
        setSent('queued');
        setTimeout(() => setSent(false), 4000);
      } else {
        setError(e.response?.data?.error || 'Failed to broadcast. Check connection.');
      }
    }
    setSending(false);
  };

  const priorityColor = { critical: 'var(--red)', high: 'var(--amber)', medium: 'var(--medium)', low: 'var(--green)' }[priority];

  const gpsButtonLabel = gpsStatus === 'loading' ? '⏳ Getting...' : gpsStatus === 'success' ? '✓ Got GPS' : '📍 GPS';
  const gpsButtonColor = gpsStatus === 'success' ? 'var(--green)' : gpsStatus === 'error' ? 'var(--red)' : 'var(--text-dim)';

  return (
    <div style={{ padding: 16, height: '100%', overflowY: 'auto' }}>
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 10, color: 'var(--text-muted)', letterSpacing: 2, marginBottom: 4 }}>
          EMERGENCY BROADCAST
        </div>
        <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>
          Message propagates across the mesh — no internet needed.
        </div>
      </div>

      {!connected && (
        <div style={{
          background: 'rgba(255,170,0,0.1)', border: '1px solid rgba(255,170,0,0.3)',
          borderRadius: 3, padding: '8px 12px', marginBottom: 14,
          fontSize: 11, color: 'var(--amber)'
        }}>
          ⚠ You are offline — message will be queued and sent when server reconnects
        </div>
      )}

      <label style={labelStyle}>YOUR NAME / IDENTIFIER</label>
      <input
        value={sender}
        onChange={e => setSender(e.target.value)}
        placeholder="e.g. Priya (Rescue Team A)"
        style={inputStyle}
      />

      <label style={{ ...labelStyle, marginTop: 4 }}>MESSAGE</label>
      <textarea
        value={content}
        onChange={e => setContent(e.target.value)}
        placeholder="Describe the situation clearly. Include location if possible."
        rows={4}
        style={{ ...inputStyle, resize: 'vertical', minHeight: 90, lineHeight: 1.6 }}
      />

      {autoMode && content.trim() && (
        <div style={{ fontSize: 10, color: 'var(--teal)', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
          <span>◈ AI classified as</span>
          <span style={{ color: priorityColor, fontWeight: 700 }}>{priority.toUpperCase()}</span>
          <span>/</span>
          <span style={{ color: 'var(--text-dim)' }}>{CATEGORY_ICONS[category]} {category}</span>
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        <div style={{ flex: 1 }}>
          <label style={{ ...labelStyle, marginBottom: 4 }}>CATEGORY {autoMode && '(AUTO)'}</label>
          <select value={category} onChange={e => setCategory(e.target.value)} disabled={autoMode} style={selectStyle}>
            {CATEGORIES.map(c => <option key={c} value={c}>{CATEGORY_ICONS[c]} {c.toUpperCase()}</option>)}
          </select>
        </div>
        <div style={{ flex: 1 }}>
          <label style={{ ...labelStyle, marginBottom: 4 }}>PRIORITY {autoMode && '(AUTO)'}</label>
          <select value={priority} onChange={e => setPriority(e.target.value)} disabled={autoMode}
            style={{ ...selectStyle, color: priorityColor, borderColor: priorityColor + '60' }}>
            {PRIORITIES.map(p => <option key={p} value={p}>{p.toUpperCase()}</option>)}
          </select>
        </div>
      </div>

      <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, cursor: 'pointer' }}>
        <div onClick={() => setAutoMode(!autoMode)} style={{
          width: 32, height: 18, borderRadius: 9, position: 'relative', cursor: 'pointer',
          background: autoMode ? 'var(--teal)' : 'var(--border)', transition: 'background 0.2s'
        }}>
          <div style={{
            position: 'absolute', top: 2, left: autoMode ? 16 : 2,
            width: 14, height: 14, borderRadius: '50%', background: '#fff', transition: 'left 0.2s'
          }} />
        </div>
        <span style={{ fontSize: 11, color: 'var(--text-dim)' }}>AI auto-classify</span>
      </label>

      {/* Location section */}
      <div style={{ marginBottom: 14 }}>
        <label style={labelStyle}>LOCATION (OPTIONAL)</label>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            value={location.name}
            onChange={e => setLocation(l => ({ ...l, name: e.target.value }))}
            placeholder="Area / landmark name"
            style={{ ...inputStyle, flex: 1, marginBottom: 0 }}
          />
          <button
            onClick={gpsStatus === 'success' ? clearLocation : getLocation}
            disabled={gpsStatus === 'loading'}
            style={{
              ...ghostBtnStyle,
              color: gpsButtonColor,
              borderColor: gpsStatus === 'success' ? 'rgba(0,230,118,0.4)' : gpsStatus === 'error' ? 'rgba(255,59,59,0.4)' : 'var(--border)'
            }}
          >
            {gpsButtonLabel}
          </button>
        </div>

        {gpsStatus === 'success' && location.lat && (
          <div style={{ fontSize: 10, color: 'var(--green)', marginTop: 5, display: 'flex', alignItems: 'center', gap: 6 }}>
            ✓ {location.lat.toFixed(5)}, {location.lng.toFixed(5)}
            <span style={{ color: 'var(--text-muted)', cursor: 'pointer' }} onClick={clearLocation}>× clear</span>
          </div>
        )}

        {gpsStatus === 'loading' && (
          <div style={{ fontSize: 10, color: 'var(--teal)', marginTop: 5 }}>
            Acquiring GPS signal... (allow location in browser popup)
          </div>
        )}

        {/* Mac GPS instructions */}
        {gpsStatus === 'error' && (
          <div style={{
            background: 'rgba(255,59,59,0.08)', border: '1px solid rgba(255,59,59,0.25)',
            borderRadius: 3, padding: '8px 10px', marginTop: 6, fontSize: 10, color: 'var(--red)', lineHeight: 1.8
          }}>
            To enable on Mac:<br />
            1. Apple menu → System Settings → Privacy &amp; Security → Location Services → ON<br />
            2. Scroll down → Safari (or Chrome) → Allow<br />
            3. Try GPS button again
          </div>
        )}
      </div>

      {error && !error.includes('Location') && (
        <div style={{ background: 'rgba(255,59,59,0.12)', border: '1px solid rgba(255,59,59,0.3)',
          borderRadius: 3, padding: '8px 12px', fontSize: 11, color: 'var(--red)', marginBottom: 12 }}>
          ⚠ {error}
        </div>
      )}

      <button onClick={handleSend} disabled={sending || !!sent} style={{
        width: '100%', padding: '12px', borderRadius: 3,
        background: sent === 'queued' ? 'rgba(255,170,0,0.12)' : sent ? 'rgba(0,230,118,0.15)' : 'rgba(255,59,59,0.15)',
        border: `1px solid ${sent === 'queued' ? 'rgba(255,170,0,0.4)' : sent ? 'rgba(0,230,118,0.5)' : 'rgba(255,59,59,0.5)'}`,
        color: sent === 'queued' ? 'var(--amber)' : sent ? 'var(--green)' : 'var(--red)',
        fontSize: 11, fontWeight: 700, letterSpacing: 2, cursor: sending ? 'wait' : 'pointer',
        fontFamily: 'var(--font-mono)', transition: 'all 0.2s'
      }}>
        {sent === 'queued' ? '⏳ QUEUED — WILL SEND WHEN ONLINE' : sent ? '✓ BROADCAST SENT' : sending ? 'BROADCASTING...' : '▶ BROADCAST TO MESH NETWORK'}
      </button>

      <div style={{ marginTop: 12, fontSize: 10, color: 'var(--text-muted)', lineHeight: 1.8 }}>
        ◦ Message hops up to 10 nodes via local Wi-Fi<br />
        ◦ Stored 72 hours across all nodes<br />
        ◦ No internet required
      </div>
    </div>
  );
}

const labelStyle = { display: 'block', fontSize: 10, color: 'var(--text-muted)', letterSpacing: 1, marginBottom: 4 };
const inputStyle = {
  width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)',
  borderRadius: 3, padding: '8px 10px', color: 'var(--text)',
  fontFamily: 'var(--font-mono)', fontSize: 12, outline: 'none', marginBottom: 12, display: 'block'
};
const selectStyle = {
  width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)',
  borderRadius: 3, padding: '8px 10px', color: 'var(--text)',
  fontFamily: 'var(--font-mono)', fontSize: 11, outline: 'none', cursor: 'pointer'
};
const ghostBtnStyle = {
  background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 3,
  padding: '8px 10px', fontSize: 11, cursor: 'pointer',
  fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap', transition: 'all 0.2s'
};
