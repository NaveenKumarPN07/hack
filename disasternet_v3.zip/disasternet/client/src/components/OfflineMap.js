import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { PRIORITY_COLORS, CATEGORY_ICONS } from '../utils/helpers';

// Fix default marker icons broken by webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

export default function OfflineMap({ messages }) {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);
  const [selected, setSelected] = useState(null);

  // Init map once
  useEffect(() => {
    if (mapInstanceRef.current) return;
    if (!mapRef.current) return;

    const map = L.map(mapRef.current, {
      center: [20.5937, 78.9629],
      zoom: 5,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(map);

    mapInstanceRef.current = map;

    // Force size recalculation
    setTimeout(() => map.invalidateSize(), 200);
  }, []);

  // Update markers when messages change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Remove old markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    const withLocation = messages.filter(m => m.location?.lat && m.location?.lng);

    withLocation.forEach(msg => {
      const color = PRIORITY_COLORS[msg.priority] || '#888';
      const icon = L.divIcon({
        className: '',
        html: `<div style="
          width: 30px; height: 30px; border-radius: 50%;
          background: ${color}22;
          border: 2px solid ${color};
          display: flex; align-items: center; justify-content: center;
          font-size: 14px; cursor: pointer;
          box-shadow: 0 0 12px ${color}88;
        ">${CATEGORY_ICONS[msg.category] || '📢'}</div>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15],
      });

      const marker = L.marker([msg.location.lat, msg.location.lng], { icon });
      marker.on('click', () => setSelected(msg));
      marker.addTo(map);
      markersRef.current.push(marker);
    });

    if (withLocation.length > 0) {
      const bounds = withLocation.map(m => [m.location.lat, m.location.lng]);
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [messages]);

  const withLocation = messages.filter(m => m.location?.lat && m.location?.lng);

  return (
    <div style={{ height: '100%', position: 'relative', background: '#080b0f' }}>
      {/* Map container */}
      <div ref={mapRef} style={{ height: '100%', width: '100%' }} />

      {/* No locations overlay */}
      {withLocation.length === 0 && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(8,11,15,0.92)', border: '1px solid var(--border)',
          borderRadius: 6, padding: '20px 28px', textAlign: 'center',
          pointerEvents: 'none', zIndex: 1000,
        }}>
          <div style={{ fontSize: 28, marginBottom: 10 }}>🗺️</div>
          <div style={{ fontSize: 13, color: 'var(--text-dim)', marginBottom: 4 }}>No geotagged alerts yet</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
            Use GPS when broadcasting to plot on map
          </div>
        </div>
      )}

      {/* Count badge */}
      <div style={{
        position: 'absolute', top: 12, right: 12, zIndex: 1000,
        background: 'rgba(8,11,15,0.9)', border: '1px solid var(--border)',
        borderRadius: 3, padding: '4px 10px',
        fontSize: 10, color: 'var(--text-dim)', letterSpacing: 1,
      }}>
        {withLocation.length} PLOTTED / {messages.length} TOTAL
      </div>

      {/* Selected alert popup */}
      {selected && (
        <div style={{
          position: 'absolute', bottom: 16, left: 16, right: 16, zIndex: 1000,
          background: 'rgba(15,19,24,0.97)',
          border: `1px solid ${PRIORITY_COLORS[selected.priority]}55`,
          borderRadius: 6, padding: 16,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{
              color: PRIORITY_COLORS[selected.priority],
              fontSize: 10, fontWeight: 700, letterSpacing: 1,
            }}>
              {selected.priority?.toUpperCase()} · {CATEGORY_ICONS[selected.category]} {selected.category?.toUpperCase()}
            </span>
            <button onClick={() => setSelected(null)} style={{
              background: 'none', border: 'none',
              color: 'var(--text-muted)', cursor: 'pointer', fontSize: 16,
            }}>×</button>
          </div>
          <div style={{ fontSize: 13, color: 'var(--text)', marginBottom: 6, lineHeight: 1.5 }}>
            {selected.content}
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
            {selected.sender} {selected.location?.name ? `· 📍 ${selected.location.name}` : ''}
          </div>
        </div>
      )}
    </div>
  );
}
