// Priority helpers
export const PRIORITIES = ['critical', 'high', 'medium', 'low'];
export const CATEGORIES = ['medical', 'rescue', 'shelter', 'food', 'fire', 'flood', 'info', 'other'];

export const CATEGORY_ICONS = {
  medical: '🏥', rescue: '🚨', shelter: '🏕️', food: '🍞',
  fire: '🔥', flood: '🌊', info: 'ℹ️', other: '📢'
};

export const PRIORITY_COLORS = {
  critical: '#ff3b3b', high: '#ff8c00', medium: '#ffda00', low: '#00e676'
};

export const PRIORITY_ORDER = { critical: 0, high: 1, medium: 2, low: 3 };

export function sortByPriority(messages) {
  return [...messages].sort((a, b) => {
    const pd = PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
    if (pd !== 0) return pd;
    return new Date(b.timestamp) - new Date(a.timestamp);
  });
}

export function timeAgo(timestamp) {
  const diff = Date.now() - new Date(timestamp);
  const mins = Math.floor(diff / 60000);
  const hrs = Math.floor(mins / 60);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

// Lightweight AI triage: classify priority from keywords
export function autoClassifyPriority(content) {
  const text = content.toLowerCase();
  const critical = ['dying', 'unconscious', 'trapped', 'cardiac', 'bleeding', 'fire', 'drowning', 'collapse', 'emergency', 'critical'];
  const high = ['injured', 'medical', 'help', 'rescue', 'stuck', 'flood', 'urgent', 'missing', 'danger'];
  const medium = ['shelter', 'food', 'water', 'road blocked', 'need', 'supply'];

  if (critical.some(w => text.includes(w))) return 'critical';
  if (high.some(w => text.includes(w))) return 'high';
  if (medium.some(w => text.includes(w))) return 'medium';
  return 'low';
}

export function autoClassifyCategory(content) {
  const text = content.toLowerCase();
  if (/medical|doctor|hospital|injured|hurt|bleeding|pain/.test(text)) return 'medical';
  if (/rescue|trapped|stuck|missing|help me/.test(text)) return 'rescue';
  if (/shelter|camp|house|roof|staying/.test(text)) return 'shelter';
  if (/food|water|hungry|supply|ration/.test(text)) return 'food';
  if (/fire|burning|smoke/.test(text)) return 'fire';
  if (/flood|water level|river|rain/.test(text)) return 'flood';
  return 'info';
}
