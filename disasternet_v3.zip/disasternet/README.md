# DisasterNet 🚨

**Offline-first emergency mesh communication network**  
*Built for Protocol BMSCE Mega Hackathon — Problem Statement 01*

---

## What it does

DisasterNet turns every smartphone into a mesh node. When cell towers fall during disasters (earthquakes, floods, cyclones), DisasterNet lets people share critical alerts — medical emergencies, blocked roads, shelter locations — over **local Wi-Fi with zero internet**.

Messages hop device-to-device using a gossip protocol. The more people on the mesh, the stronger the network.

---

## Features

| Feature | Description |
|---|---|
| 🔴 Real-time alert feed | Socket.IO pushes every message instantly to all connected browsers |
| 🤖 AI auto-triage | Keyword-based on-device classifier sets priority + category as you type |
| 🗺️ Offline map | Leaflet + OSM tiles with priority-colored alert markers |
| 🔄 Gossip protocol | TTL=10 hop counter, SHA-256 dedup, 30s peer sync |
| 💾 Store & forward | 72-hour MongoDB cache (falls back to in-memory) |
| 📱 PWA-ready | Works offline, add to home screen, no app store needed |
| 🌐 Multi-node mesh | Set PEERS env var to connect nodes across a Wi-Fi area |

---

## Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (optional — works in-memory without it)

### 1. Clone and install

```bash
git clone <your-repo>
cd disasternet

# Install server dependencies
cd server && npm install && cd ..

# Install client dependencies  
cd client && npm install && cd ..
```

### 2. Start the server

```bash
cd server
node index.js
```

Server starts on **http://localhost:5000**

### 3. Start the React client (development)

```bash
cd client
npm start
```

Client opens at **http://localhost:3000**

---

## Multi-node mesh setup

To connect multiple phones/laptops on the same Wi-Fi hotspot:

**Node 1 (e.g. laptop, IP: 192.168.1.100):**
```bash
PORT=5000 NODE_ID=node-alpha node server/index.js
```

**Node 2 (e.g. another laptop, IP: 192.168.1.101):**
```bash
PORT=5000 NODE_ID=node-beta PEERS=http://192.168.1.100:5000 node server/index.js
```

Now any message broadcast on Node 1 automatically propagates to Node 2 and vice versa — **no internet required**.

---

## Architecture

```
User opens app (PWA cached)
    ↓
POST /api/messages → Express → SHA-256 hash → MongoDB (dedup)
    ↓
io.emit() → Socket.IO → All connected browsers (instant)
    ↓
Gossip forward → POST to peer nodes (TTL-1, hopCount+1)
    ↓
Stops at TTL=0 or already-seen hash
```

### Tech stack

**Application layer:** MongoDB · Express.js · React · Node.js · Socket.IO  
**Transport:** Local Wi-Fi hotspot · HTTP peer sync (every 30s)  
**AI layer:** On-device keyword triage (no internet, 0ms latency)  
**Map:** Leaflet + OpenStreetMap (pre-cacheable tiles)

---

## Project structure

```
disasternet/
├── server/
│   ├── index.js          # Express + Socket.IO + gossip engine
│   └── package.json
├── client/
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── App.js
│       ├── components/
│       │   ├── Header.js           # Nav + node status
│       │   ├── AlertFeed.js        # Real-time message list
│       │   ├── BroadcastComposer.js # Send alerts + AI classify
│       │   ├── OfflineMap.js       # Leaflet map
│       │   └── NetworkPanel.js     # Node info + how it works
│       ├── hooks/
│       │   └── useDisasterNet.js   # Socket + API hooks
│       └── utils/
│           └── helpers.js          # AI triage, priority utils
└── README.md
```

---

## Hackathon notes

- **Zero infrastructure**: Works with just a phone hotspot
- **No cloud cost**: Fully peer-to-peer, ₹0/month running cost  
- **72-hour persistence**: Messages survive node restarts
- **Scales with crowd**: More devices = stronger mesh
- **LoRa-ready**: Backend designed to accept LoRa bridge messages at `/api/messages/gossip`

---

*Team AvengerS · Protocol BMSCE Mega Hackathon · 13 March*
