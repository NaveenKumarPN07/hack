import React, { useState, useEffect } from "react";
import AlertFeed from "./components/AlertFeed";
import BroadcastComposer from "./components/BroadcastComposer";
import OfflineMap from "./components/OfflineMap";
import NodeStatus from "./components/NodeStatus";
import { useSocket } from "./utils/socket";
import "./App.css";

const TABS = [
  { id: "feed", label: "📡 Feed", icon: "📡" },
  { id: "broadcast", label: "📢 Broadcast", icon: "📢" },
  { id: "map", label: "🗺️ Map", icon: "🗺️" },
  { id: "status", label: "⚙️ Status", icon: "⚙️" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState("feed");
  const [messages, setMessages] = useState([]);
  const [newCount, setNewCount] = useState(0);
  const { socket, connected } = useSocket();

  // Listen for real-time messages
  useEffect(() => {
    if (!socket) return;
    socket.on("new_message", (msg) => {
      setMessages((prev) => {
        // Dedup by hash
        if (prev.find((m) => m.hash === msg.hash)) return prev;
        if (activeTab !== "feed") setNewCount((c) => c + 1);
        return [msg, ...prev].sort((a, b) => a.priority - b.priority);
      });
    });
    return () => socket.off("new_message");
  }, [socket, activeTab]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    if (tab === "feed") setNewCount(0);
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-left">
          <span className="logo">🌐 DisasterNet</span>
          <span className={`connection-dot ${connected ? "connected" : "disconnected"}`} />
          <span className="connection-label">
            {connected ? "Node Online" : "Reconnecting..."}
          </span>
        </div>
        <div className="header-right">
          <span className="mesh-label">MESH ACTIVE</span>
        </div>
      </header>

      {/* Main content */}
      <main className="app-main">
        {activeTab === "feed" && (
          <AlertFeed messages={messages} setMessages={setMessages} />
        )}
        {activeTab === "broadcast" && (
          <BroadcastComposer onSent={() => handleTabChange("feed")} />
        )}
        {activeTab === "map" && <OfflineMap messages={messages} />}
        {activeTab === "status" && <NodeStatus connected={connected} />}
      </main>

      {/* Bottom nav */}
      <nav className="bottom-nav">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            className={`nav-tab ${activeTab === tab.id ? "active" : ""}`}
            onClick={() => handleTabChange(tab.id)}
          >
            <span className="nav-icon">{tab.icon}</span>
            <span className="nav-label">{tab.label.split(" ")[1]}</span>
            {tab.id === "feed" && newCount > 0 && (
              <span className="badge-count">{newCount}</span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}
