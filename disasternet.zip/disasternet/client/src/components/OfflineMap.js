import React, { useEffect, useRef } from "react";
import "./OfflineMap.css";

const PRIORITY_COLORS = {
  1: "#ff4757",
  2: "#ff6b35",
  3: "#ffb347",
  4: "#70a1ff",
};

export default function OfflineMap({ messages }) {
  const mapRef = useRef(null);
  const leafletMap = useRef(null);
  const markersRef = useRef({});

  // Initialize Leaflet map
  useEffect(() => {
    if (leafletMap.current || !mapRef.current) return;

    // Dynamic import - Leaflet needs window
    import("leaflet").then((L) => {
      const map = L.map(mapRef.current, {
        center: [20.5937, 78.9629], // Center of India
        zoom: 5,
        zoomControl: true,
      });

      // OpenStreetMap tiles — cached by service worker after first load
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        maxZoom: 19,
      }).addTo(map);

      leafletMap.current = map;

      // Add markers for existing messages with location
      messages.forEach((msg) => addMarker(L, map, msg));
    });

    return () => {
      if (leafletMap.current) {
        leafletMap.current.remove();
        leafletMap.current = null;
      }
    };
  }, []); // eslint-disable-line

  // Add/update markers when messages change
  useEffect(() => {
    if (!leafletMap.current) return;

    import("leaflet").then((L) => {
      messages.forEach((msg) => {
        if (!msg.location?.lat || !msg.location?.lng) return;
        if (markersRef.current[msg.hash]) return; // already on map
        addMarker(L, leafletMap.current, msg);
      });
    });
  }, [messages]);

  function addMarker(L, map, msg) {
    if (!msg.location?.lat || !msg.location?.lng) return;

    const color = PRIORITY_COLORS[msg.priority] || "#aaa";

    // Custom circle marker icon
    const icon = L.divIcon({
      className: "",
      html: `<div style="
        width:20px;height:20px;
        background:${color};
        border:3px solid white;
        border-radius:50%;
        box-shadow:0 0 8px ${color};
        cursor:pointer;
      "></div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });

    const marker = L.marker([msg.location.lat, msg.location.lng], { icon });

    // Popup with message info
    marker.bindPopup(`
      <div style="font-family:sans-serif;min-width:180px">
        <b style="color:${color}">${msg.category?.toUpperCase()}</b>
        <p style="margin:6px 0;font-size:13px">${msg.content}</p>
        <small style="color:#666">by ${msg.sender}</small>
      </div>
    `);

    marker.addTo(map);
    markersRef.current[msg.hash] = marker;
  }

  const locatedMessages = messages.filter((m) => m.location?.lat);

  return (
    <div className="offline-map-container">
      <div className="map-header">
        <h3>🗺️ Offline Alert Map</h3>
        <span className="map-count">
          {locatedMessages.length} located alert{locatedMessages.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Legend */}
      <div className="map-legend">
        {Object.entries(PRIORITY_COLORS).map(([p, color]) => (
          <span key={p} className="legend-item">
            <span className="legend-dot" style={{ background: color }} />
            {["Critical", "High", "Medium", "Low"][p - 1]}
          </span>
        ))}
      </div>

      {/* Map container */}
      <div ref={mapRef} className="leaflet-map" />

      {locatedMessages.length === 0 && (
        <div className="map-empty-hint">
          <p>No alerts with GPS coordinates yet.</p>
          <p>When broadcasting, tap "Attach GPS Location".</p>
        </div>
      )}
    </div>
  );
}
