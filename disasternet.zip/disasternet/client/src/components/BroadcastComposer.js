import React, { useState, useEffect, useRef } from "react";
import { api, CATEGORIES, getDeviceId } from "../utils/socket";
import { createDebouncedTriage, detectLanguage } from "../utils/ai";
import "./BroadcastComposer.css";

const PRIORITY_LABELS = { 1: "🔴 CRITICAL", 2: "🟠 HIGH", 3: "🟡 MEDIUM", 4: "🔵 LOW" };

export default function BroadcastComposer({ onSent }) {
  const [content, setContent] = useState("");
  const [sender, setSender] = useState(() => localStorage.getItem("dn_sender") || "");
  const [category, setCategory] = useState("emergency");
  const [priority, setPriority] = useState(3);
  const [location, setLocation] = useState(null);
  const [aiPriority, setAiPriority] = useState(null);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [locating, setLocating] = useState(false);
  const textareaRef = useRef(null);

  // Debounced AI triage on content change
  const debouncedTriage = useRef(
    createDebouncedTriage((result) => {
      setAiPriority(result);
      setPriority(result.priority); // auto-set priority from AI
    }, 600)
  );

  useEffect(() => {
    if (content.trim().length > 5) {
      debouncedTriage.current(content);
    } else {
      setAiPriority(null);
    }
  }, [content]);

  const handleSend = async () => {
    if (!content.trim()) return setError("Message cannot be empty");
    if (!sender.trim()) return setError("Please enter your name or device ID");

    setSending(true);
    setError(null);

    try {
      localStorage.setItem("dn_sender", sender.trim());

      const lang = detectLanguage(content);
      const result = await api.postMessage({
        content: content.trim(),
        sender: sender.trim(),
        category,
        priority,
        location: location || {},
        language: lang,
      });

      if (result.success) {
        setSuccess(true);
        setContent("");
        setAiPriority(null);
        setTimeout(() => {
          setSuccess(false);
          onSent?.();
        }, 1500);
      } else if (result.error?.includes("Duplicate")) {
        setError("⚠️ This message already exists in the network");
      } else {
        setError(result.error || "Failed to send");
      }
    } catch (err) {
      setError("Cannot reach node server. Is it running?");
    } finally {
      setSending(false);
    }
  };

  const getLocation = () => {
    if (!navigator.geolocation) return setError("Geolocation not available");
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocating(false);
      },
      () => {
        setError("Could not get location");
        setLocating(false);
      }
    );
  };

  const charCount = content.length;
  const isOverLimit = charCount > 1000;

  return (
    <div className="composer">
      <div className="composer-header">
        <h2>📢 Broadcast Alert</h2>
        <p className="composer-sub">Message will propagate through the mesh network</p>
      </div>

      <div className="composer-body">
        {/* Sender */}
        <div className="field">
          <label>Your Name / Device ID</label>
          <input
            type="text"
            placeholder="e.g. Rescue Team A / Ravi Kumar"
            value={sender}
            onChange={(e) => setSender(e.target.value)}
            maxLength={100}
            className="input"
          />
        </div>

        {/* Category */}
        <div className="field">
          <label>Category</label>
          <div className="category-grid">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.value}
                className={`cat-btn ${category === cat.value ? "active" : ""}`}
                style={{ "--cat-color": cat.color }}
                onClick={() => setCategory(cat.value)}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Message */}
        <div className="field">
          <label>
            Message
            {aiPriority && (
              <span className="ai-tag">
                🤖 AI: {PRIORITY_LABELS[aiPriority.priority]}
                <span className="ai-conf">
                  {Math.round(aiPriority.confidence * 100)}%
                </span>
              </span>
            )}
          </label>
          <textarea
            ref={textareaRef}
            placeholder="Describe the situation clearly. Include location, number of people, and what help is needed."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={5}
            maxLength={1000}
            className={`textarea ${isOverLimit ? "over-limit" : ""}`}
          />
          <span className={`char-count ${isOverLimit ? "over" : ""}`}>
            {charCount}/1000
          </span>
        </div>

        {/* Priority override */}
        <div className="field">
          <label>Priority</label>
          <div className="priority-row">
            {[1, 2, 3, 4].map((p) => (
              <button
                key={p}
                className={`priority-btn priority-${p} ${priority === p ? "active" : ""}`}
                onClick={() => setPriority(p)}
              >
                {PRIORITY_LABELS[p]}
              </button>
            ))}
          </div>
        </div>

        {/* Location */}
        <div className="field">
          <label>Location (optional)</label>
          <button
            className={`btn btn-ghost location-btn ${location ? "has-location" : ""}`}
            onClick={getLocation}
            disabled={locating}
          >
            {locating
              ? "⏳ Getting location..."
              : location
              ? `📍 ${location.lat.toFixed(4)}, ${location.lng.toFixed(4)} ✓`
              : "📍 Attach GPS Location"}
          </button>
          {location && (
            <button className="clear-loc" onClick={() => setLocation(null)}>
              ✕ Remove
            </button>
          )}
        </div>

        {/* Error / Success */}
        {error && <div className="alert-error">⚠️ {error}</div>}
        {success && (
          <div className="alert-success">
            ✅ Broadcast sent! Propagating through mesh...
          </div>
        )}

        {/* Send button */}
        <button
          className={`btn btn-primary send-btn ${sending ? "sending" : ""}`}
          onClick={handleSend}
          disabled={sending || isOverLimit || !content.trim()}
        >
          {sending ? "⏳ Sending..." : "📡 Broadcast to Mesh"}
        </button>
      </div>
    </div>
  );
}
