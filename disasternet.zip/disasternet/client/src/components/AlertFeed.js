import React, { useEffect, useState } from "react";
import { api, PRIORITY, CATEGORIES } from "../utils/socket";
import "./AlertFeed.css";

const CATEGORY_META = Object.fromEntries(
  CATEGORIES.map((c) => [c.value, c])
);

const PRIORITY_LABELS = { 1: "CRITICAL", 2: "HIGH", 3: "MEDIUM", 4: "LOW" };

function timeAgo(date) {
  const secs = Math.floor((Date.now() - new Date(date)) / 1000);
  if (secs < 60) return `${secs}s ago`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ago`;
  if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`;
  return `${Math.floor(secs / 86400)}d ago`;
}

export default function AlertFeed({ messages, setMessages }) {
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [error, setError] = useState(null);

  // Load existing messages on mount
  useEffect(() => {
    api.getMessages({ limit: 100 })
      .then((data) => {
        if (data.success) {
          setMessages(data.messages.sort((a, b) => a.priority - b.priority));
        }
      })
      .catch(() => setError("Could not reach node server"))
      .finally(() => setLoading(false));
  }, [setMessages]);

  const filtered = filter === "all"
    ? messages
    : messages.filter((m) => m.category === filter);

  const criticalCount = messages.filter((m) => m.priority === 1).length;

  return (
    <div className="alert-feed">
      {/* Critical banner */}
      {criticalCount > 0 && (
        <div className="critical-banner pulse">
          🚨 {criticalCount} CRITICAL ALERT{criticalCount > 1 ? "S" : ""} ACTIVE
        </div>
      )}

      {/* Filter chips */}
      <div className="filter-bar">
        <button
          className={`filter-chip ${filter === "all" ? "active" : ""}`}
          onClick={() => setFilter("all")}
        >
          All ({messages.length})
        </button>
        {CATEGORIES.filter((c) =>
          messages.some((m) => m.category === c.value)
        ).map((cat) => (
          <button
            key={cat.value}
            className={`filter-chip ${filter === cat.value ? "active" : ""}`}
            onClick={() => setFilter(cat.value)}
            style={{ "--chip-color": cat.color }}
          >
            {cat.label.split(" ")[0]}{" "}
            {messages.filter((m) => m.category === cat.value).length}
          </button>
        ))}
      </div>

      {/* Feed */}
      <div className="feed-list">
        {loading && (
          <div className="feed-empty">
            <div className="spinner" />
            <p>Connecting to node...</p>
          </div>
        )}

        {error && !loading && (
          <div className="feed-empty feed-error">
            <p>⚠️ {error}</p>
            <p className="hint">Make sure the server is running on port 3001</p>
          </div>
        )}

        {!loading && !error && filtered.length === 0 && (
          <div className="feed-empty">
            <p>📡 No alerts yet</p>
            <p className="hint">Waiting for messages from the mesh network...</p>
          </div>
        )}

        {filtered.map((msg) => (
          <MessageCard key={msg._id || msg.hash} msg={msg} />
        ))}
      </div>
    </div>
  );
}

function MessageCard({ msg }) {
  const cat = CATEGORY_META[msg.category] || CATEGORY_META.other;
  const priorityColor = PRIORITY[msg.priority]?.color || "#aaa";
  const priorityLabel = PRIORITY_LABELS[msg.priority] || "LOW";

  return (
    <div
      className={`message-card animate-in priority-${msg.priority}`}
      style={{ "--p-color": priorityColor }}
    >
      <div className="card-header">
        <span className="card-category" style={{ color: cat.color }}>
          {cat.label}
        </span>
        <span className={`card-priority badge badge-${msg.priority}`}>
          {priorityLabel}
        </span>
        <span className="card-time">{timeAgo(msg.createdAt)}</span>
      </div>

      <p className="card-content">{msg.content}</p>

      <div className="card-footer">
        <span className="card-sender">
          {msg.isVerified ? "✅" : "👤"} {msg.sender}
        </span>
        {msg.hopCount > 0 && (
          <span className="card-hops" title="Hops through mesh">
            🔁 {msg.hopCount} hop{msg.hopCount > 1 ? "s" : ""}
          </span>
        )}
        {msg.location?.lat && (
          <span className="card-location">📍 Located</span>
        )}
      </div>
    </div>
  );
}
