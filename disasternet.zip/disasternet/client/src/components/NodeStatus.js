import React, { useEffect, useState } from "react";
import { api } from "../utils/socket";
import "./NodeStatus.css";

export default function NodeStatus({ connected }) {
  const [health, setHealth] = useState(null);
  const [peers, setPeers] = useState([]);
  const [peerStatus, setPeerStatus] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.getHealth(), api.getPeers()])
      .then(([h, p]) => {
        if (h.status === "ok") setHealth(h);
        if (p.success) setPeers(p.peers);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  // Ping each peer
  useEffect(() => {
    if (peers.length === 0) return;
    peers.forEach(async (peer) => {
      try {
        const res = await fetch(`${peer}/api/health`, { signal: AbortSignal.timeout(3000) });
        const data = await res.json();
        setPeerStatus((prev) => ({ ...prev, [peer]: data.status === "ok" ? "online" : "error" }));
      } catch {
        setPeerStatus((prev) => ({ ...prev, [peer]: "offline" }));
      }
    });
  }, [peers]);

  const uptimeStr = health?.uptime
    ? `${Math.floor(health.uptime / 3600)}h ${Math.floor((health.uptime % 3600) / 60)}m`
    : "—";

  return (
    <div className="node-status">
      <div className="status-header">
        <h2>⚙️ Node Status</h2>
        <span className={`node-badge ${connected ? "online" : "offline"}`}>
          {connected ? "● ONLINE" : "● OFFLINE"}
        </span>
      </div>

      <div className="status-body">
        {/* This Node */}
        <section className="status-section">
          <h3>This Node</h3>
          {loading ? (
            <p className="muted">Loading...</p>
          ) : health ? (
            <div className="stat-grid">
              <StatRow label="Node Name" value={health.node} />
              <StatRow label="Uptime" value={uptimeStr} />
              <StatRow label="Socket" value={connected ? "✅ Connected" : "❌ Disconnected"} />
              <StatRow label="Time" value={new Date(health.timestamp).toLocaleTimeString()} />
            </div>
          ) : (
            <p className="muted warn">⚠️ Server not reachable. Is it running on port 3001?</p>
          )}
        </section>

        {/* Peer Nodes */}
        <section className="status-section">
          <h3>Mesh Peers ({peers.length})</h3>
          {peers.length === 0 ? (
            <div className="no-peers">
              <p>No peers configured.</p>
              <p className="hint">
                To enable multi-node mesh, add peer IPs to your <code>server/.env</code>:
              </p>
              <code className="code-block">
                PEERS=http://192.168.1.101:3001,http://192.168.1.102:3001
              </code>
            </div>
          ) : (
            <div className="peer-list">
              {peers.map((peer) => (
                <div key={peer} className="peer-row">
                  <span className={`peer-dot ${peerStatus[peer] || "checking"}`} />
                  <span className="peer-url">{peer}</span>
                  <span className={`peer-status ${peerStatus[peer] || "checking"}`}>
                    {peerStatus[peer] === "online"
                      ? "Online"
                      : peerStatus[peer] === "offline"
                      ? "Offline"
                      : "Checking..."}
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* How it works */}
        <section className="status-section">
          <h3>How the Mesh Works</h3>
          <div className="info-cards">
            <InfoCard icon="📡" title="Wi-Fi Hotspot" desc="One phone creates a hotspot. All other devices connect to it. No internet needed." />
            <InfoCard icon="🔁" title="Gossip Protocol" desc="Messages hop device-to-device. TTL=10 means 10 hops maximum." />
            <InfoCard icon="💾" title="72h Cache" desc="All messages stored for 72 hours. Offline devices sync when they reconnect." />
            <InfoCard icon="📻" title="LoRa Extension" desc="Add LORA_PORT to .env to extend range to 15km via radio hardware." />
          </div>
        </section>

        {/* Quick setup guide */}
        <section className="status-section">
          <h3>Quick Setup</h3>
          <ol className="setup-steps">
            <li>One device runs <code>npm run dev</code> as the mesh node</li>
            <li>It creates a Wi-Fi hotspot (phone) or uses LAN</li>
            <li>Others connect to that hotspot and open <code>http://&lt;node-ip&gt;:3001</code></li>
            <li>Add more nodes by setting <code>PEERS</code> in <code>.env</code></li>
          </ol>
        </section>
      </div>
    </div>
  );
}

function StatRow({ label, value }) {
  return (
    <div className="stat-row">
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value}</span>
    </div>
  );
}

function InfoCard({ icon, title, desc }) {
  return (
    <div className="info-card">
      <span className="info-icon">{icon}</span>
      <div>
        <strong>{title}</strong>
        <p>{desc}</p>
      </div>
    </div>
  );
}
