import { useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";

const SERVER_URL = process.env.REACT_APP_SERVER_URL || "";

// Singleton socket connection
let socket = null;

export function getSocket() {
  if (!socket) {
    socket = io(SERVER_URL, {
      transports: ["websocket", "polling"],
      reconnectionAttempts: Infinity,
      reconnectionDelay: 2000,
    });
  }
  return socket;
}

/**
 * useSocket - React hook for real-time Socket.IO connection
 */
export function useSocket() {
  const [connected, setConnected] = useState(false);
  const socketRef = useRef(getSocket());

  useEffect(() => {
    const s = socketRef.current;
    s.on("connect", () => setConnected(true));
    s.on("disconnect", () => setConnected(false));
    if (s.connected) setConnected(true);
    return () => {
      s.off("connect");
      s.off("disconnect");
    };
  }, []);

  return { socket: socketRef.current, connected };
}

/**
 * API helpers - all calls go to local server (no internet)
 */
export const api = {
  async getMessages(params = {}) {
    const qs = new URLSearchParams(params).toString();
    const res = await fetch(`/api/messages${qs ? "?" + qs : ""}`);
    return res.json();
  },

  async postMessage(data) {
    const res = await fetch("/api/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    return res.json();
  },

  async getHealth() {
    const res = await fetch("/api/health");
    return res.json();
  },

  async getPeers() {
    const res = await fetch("/api/peers");
    return res.json();
  },
};

/**
 * Generate a device ID stored in localStorage
 */
export function getDeviceId() {
  let id = localStorage.getItem("disasternet_device_id");
  if (!id) {
    id = "device_" + Math.random().toString(36).substring(2, 10);
    localStorage.setItem("disasternet_device_id", id);
  }
  return id;
}

/**
 * Priority labels and colors
 */
export const PRIORITY = {
  1: { label: "CRITICAL", color: "#ff4757" },
  2: { label: "HIGH", color: "#ff6b35" },
  3: { label: "MEDIUM", color: "#ffb347" },
  4: { label: "LOW", color: "#70a1ff" },
};

export const CATEGORIES = [
  { value: "emergency", label: "🆘 Emergency", color: "#ff4757" },
  { value: "medical", label: "🏥 Medical", color: "#ff6b35" },
  { value: "rescue", label: "⛑️ Rescue", color: "#ff9f43" },
  { value: "shelter", label: "🏠 Shelter", color: "#00d4aa" },
  { value: "food", label: "🍽️ Food/Water", color: "#70a1ff" },
  { value: "info", label: "ℹ️ Info", color: "#aaaaaa" },
  { value: "other", label: "📢 Other", color: "#dfe6e9" },
];
