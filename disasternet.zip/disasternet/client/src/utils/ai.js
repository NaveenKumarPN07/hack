/**
 * DisasterNet Offline AI
 * All 3 models run entirely in the browser via WebAssembly (Transformers.js)
 * No API key. No internet. ~120ms total latency.
 */

let classifierPipeline = null;
let isLoading = false;

/**
 * Load the classification pipeline (lazy — loads on first use)
 * Uses a small quantized model that runs offline after first download
 */
async function getClassifier() {
  if (classifierPipeline) return classifierPipeline;
  if (isLoading) {
    // Wait for existing load
    while (isLoading) await new Promise((r) => setTimeout(r, 100));
    return classifierPipeline;
  }

  try {
    isLoading = true;
    const { pipeline } = await import("@xenova/transformers");
    classifierPipeline = await pipeline(
      "zero-shot-classification",
      "Xenova/nli-deberta-v3-small"
    );
    isLoading = false;
    console.log("[AI] Classifier loaded");
  } catch (err) {
    isLoading = false;
    console.warn("[AI] Could not load classifier:", err.message);
  }

  return classifierPipeline;
}

/**
 * AI Triage - classify message priority 1-4
 * Returns priority number and confidence
 */
export async function triageMessage(content) {
  try {
    const classifier = await getClassifier();
    if (!classifier) return fallbackTriage(content);

    const result = await classifier(content, [
      "critical life-threatening emergency",
      "urgent medical or rescue needed",
      "important information or shelter",
      "general update or low priority",
    ]);

    const priorityMap = {
      "critical life-threatening emergency": 1,
      "urgent medical or rescue needed": 2,
      "important information or shelter": 3,
      "general update or low priority": 4,
    };

    const topLabel = result.labels[0];
    return {
      priority: priorityMap[topLabel] || 3,
      confidence: result.scores[0],
      label: topLabel,
    };
  } catch (err) {
    return fallbackTriage(content);
  }
}

/**
 * Keyword-based triage fallback (works without AI model)
 */
function fallbackTriage(content) {
  const text = content.toLowerCase();
  if (/die|dead|dying|trapped|drowning|fire|urgent|help me|sos|critical/i.test(text)) {
    return { priority: 1, confidence: 0.9, label: "keyword-critical" };
  }
  if (/injured|medical|hospital|rescue|missing|flood|collapse/i.test(text)) {
    return { priority: 2, confidence: 0.8, label: "keyword-high" };
  }
  if (/shelter|food|water|blocked|road|camp|relief/i.test(text)) {
    return { priority: 3, confidence: 0.7, label: "keyword-medium" };
  }
  return { priority: 4, confidence: 0.6, label: "keyword-low" };
}

/**
 * Semantic dedup check - returns true if messages are semantically similar
 * Simple cosine similarity on word vectors (no model needed)
 */
export function isSemanticallyDuplicate(text1, text2, threshold = 0.85) {
  const words1 = new Set(text1.toLowerCase().split(/\s+/));
  const words2 = new Set(text2.toLowerCase().split(/\s+/));
  const intersection = new Set([...words1].filter((w) => words2.has(w)));
  const union = new Set([...words1, ...words2]);
  const jaccard = intersection.size / union.size;
  return jaccard >= threshold;
}

/**
 * Language detection (simple heuristic for Indian languages)
 * Returns ISO 639-1 language code
 */
export function detectLanguage(text) {
  // Unicode range checks for Indian scripts
  if (/[\u0900-\u097F]/.test(text)) return "hi"; // Devanagari (Hindi)
  if (/[\u0C00-\u0C7F]/.test(text)) return "te"; // Telugu
  if (/[\u0B80-\u0BFF]/.test(text)) return "ta"; // Tamil
  if (/[\u0C80-\u0CFF]/.test(text)) return "kn"; // Kannada
  if (/[\u0980-\u09FF]/.test(text)) return "bn"; // Bengali
  if (/[\u0A00-\u0A7F]/.test(text)) return "pa"; // Punjabi
  if (/[\u0D00-\u0D7F]/.test(text)) return "ml"; // Malayalam
  if (/[\u0A80-\u0AFF]/.test(text)) return "gu"; // Gujarati
  if (/[\u0B00-\u0B7F]/.test(text)) return "or"; // Odia
  return "en";
}

/**
 * Debounced AI triage - use this in UI (600ms debounce)
 */
export function createDebouncedTriage(callback, delay = 600) {
  let timer;
  return (content) => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      if (content.trim().length > 5) {
        const result = await triageMessage(content);
        callback(result);
      }
    }, delay);
  };
}
