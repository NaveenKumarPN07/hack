const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const Message = require("../models/Message");
const { forwardTopeers } = require("../utils/gossip");

// GET /api/messages - fetch all messages sorted by priority
router.get("/", async (req, res) => {
  try {
    const { category, priority, limit = 100 } = req.query;
    const filter = {};
    if (category) filter.category = category;
    if (priority) filter.priority = parseInt(priority);

    const messages = await Message.find(filter)
      .sort({ priority: 1, createdAt: -1 })
      .limit(parseInt(limit))
      .lean();

    res.json({ success: true, count: messages.length, messages });
  } catch (err) {
    console.error("[API] GET /messages error:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/messages - broadcast a new message
router.post("/", async (req, res) => {
  try {
    const { content, sender, category, priority, location, language, signature } = req.body;

    if (!content || !sender) {
      return res.status(400).json({ success: false, error: "content and sender are required" });
    }

    // Generate SHA-256 hash for deduplication
    const hashInput = `${content.trim().toLowerCase()}|${sender}|${category || "info"}`;
    const hash = crypto.createHash("sha256").update(hashInput).digest("hex");

    // Check for duplicate
    const existing = await Message.findOne({ hash });
    if (existing) {
      return res.status(409).json({
        success: false,
        error: "Duplicate message",
        existingId: existing._id,
      });
    }

    // Create and save message
    const message = new Message({
      hash,
      content: content.trim(),
      sender,
      category: category || "info",
      priority: priority || 3,
      location: location || {},
      language: language || "en",
      signature: signature || null,
      isVerified: !!signature, // simplified — full Ed25519 verify in middleware
      ttl: parseInt(process.env.MESSAGE_TTL) || 10,
      hopCount: 0,
      originNode: "local",
    });

    await message.save();

    // Push to all connected browsers via Socket.IO
    const io = req.app.get("io");
    io.emit("new_message", message);

    // Forward to peer nodes (gossip)
    forwardTopeers(message.toObject());

    console.log(`[MSG] New message saved: [${message.category}] ${message.content.substring(0, 50)}...`);

    res.status(201).json({ success: true, message });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ success: false, error: "Duplicate message (hash collision)" });
    }
    console.error("[API] POST /messages error:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/messages/sync - receive gossip from peer nodes
router.post("/sync", async (req, res) => {
  try {
    const { messages } = req.body;
    if (!Array.isArray(messages)) {
      return res.status(400).json({ success: false, error: "messages array required" });
    }

    let saved = 0;
    let skipped = 0;
    const io = req.app.get("io");

    for (const msg of messages) {
      // Skip if TTL exhausted
      if (!msg.ttl || msg.ttl <= 0) { skipped++; continue; }

      try {
        const incoming = {
          ...msg,
          ttl: msg.ttl - 1,
          hopCount: (msg.hopCount || 0) + 1,
        };
        delete incoming._id; // let MongoDB generate new _id

        await Message.create(incoming);
        io.emit("new_message", incoming);
        saved++;
      } catch (e) {
        if (e.code === 11000) skipped++; // dedup — already have this hash
        else console.warn("[SYNC] Error saving peer message:", e.message);
      }
    }

    res.json({ success: true, saved, skipped });
  } catch (err) {
    console.error("[API] POST /messages/sync error:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/messages/:id - remove a message (coordinator only)
router.delete("/:id", async (req, res) => {
  try {
    await Message.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
