const express = require("express");
const router = express.Router();

// GET /api/peers - list configured peer nodes
router.get("/", (req, res) => {
  const peers = (process.env.PEERS || "").split(",").filter(Boolean);
  res.json({ success: true, peers });
});

// POST /api/peers/ping - check if this node is alive (used by peers)
router.post("/ping", (req, res) => {
  res.json({
    success: true,
    node: process.env.NODE_NAME || "DisasterNet Node",
    timestamp: new Date().toISOString(),
  });
});

module.exports = router;
