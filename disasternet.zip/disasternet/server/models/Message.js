const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
  {
    // SHA-256 hash of (content + sender + category) for deduplication
    hash: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },

    // Message content
    content: {
      type: String,
      required: true,
      maxlength: 1000,
    },

    // Sender identifier (device ID or name)
    sender: {
      type: String,
      required: true,
      maxlength: 100,
    },

    // Alert category
    category: {
      type: String,
      enum: ["emergency", "medical", "shelter", "food", "rescue", "info", "other"],
      default: "info",
    },

    // AI-classified priority (1=critical, 2=high, 3=medium, 4=low)
    priority: {
      type: Number,
      enum: [1, 2, 3, 4],
      default: 3,
    },

    // Location (if user shares it)
    location: {
      lat: { type: Number },
      lng: { type: Number },
      label: { type: String, maxlength: 200 },
    },

    // Gossip mesh metadata
    ttl: {
      type: Number,
      default: parseInt(process.env.MESSAGE_TTL) || 10,
    },
    hopCount: {
      type: Number,
      default: 0,
    },
    originNode: {
      type: String,
      default: "local",
    },

    // Cryptographic signature (Ed25519 for official alerts)
    signature: {
      type: String,
      default: null,
    },
    isVerified: {
      type: Boolean,
      default: false,
    },

    // Language of the message (for auto-translate)
    language: {
      type: String,
      default: "en",
      maxlength: 10,
    },

    // Auto-expire after 72 hours
    createdAt: {
      type: Date,
      default: Date.now,
      expires: parseInt(process.env.MESSAGE_TTL_SECONDS) || 259200, // 72h
    },
  },
  {
    timestamps: true,
  }
);

// Index for fast priority-sorted feed
messageSchema.index({ priority: 1, createdAt: -1 });
messageSchema.index({ category: 1, createdAt: -1 });

module.exports = mongoose.model("Message", messageSchema);
