/**
 * LoRa Bridge - extends mesh range to 5-15km via serial port
 * Requires: LoRa module connected via USB-to-serial adapter
 * Hardware: ~₹15 SX1276/SX1278 module
 */

let loraPort = null;

async function initLoRa(io) {
  const portPath = process.env.LORA_PORT;
  const baudRate = parseInt(process.env.LORA_BAUD) || 9600;

  if (!portPath) {
    console.log("[LoRa] No LORA_PORT configured. Skipping LoRa bridge.");
    return;
  }

  try {
    const { SerialPort } = require("serialport");
    const { ReadlineParser } = require("@serialport/parser-readline");

    loraPort = new SerialPort({ path: portPath, baudRate });
    const parser = loraPort.pipe(new ReadlineParser({ delimiter: "\n" }));

    loraPort.on("open", () => {
      console.log(`[LoRa] Bridge active on ${portPath} @ ${baudRate} baud`);
      console.log("[LoRa] Range: 5-15 km. Extending mesh to remote nodes.");
    });

    // Receive messages from LoRa network and inject into mesh
    parser.on("data", async (line) => {
      try {
        const msg = JSON.parse(line.trim());
        console.log(`[LoRa] Received: ${msg.content?.substring(0, 50)}`);

        const crypto = require("crypto");
        const Message = require("../models/Message");

        const hash = crypto
          .createHash("sha256")
          .update(`${msg.content}|${msg.sender}|${msg.category}`)
          .digest("hex");

        await Message.create({ ...msg, hash, originNode: "lora" });
        io.emit("new_message", { ...msg, hash, originNode: "lora" });
      } catch (err) {
        // Not JSON or duplicate — ignore
      }
    });

    loraPort.on("error", (err) => {
      console.error("[LoRa] Serial error:", err.message);
    });
  } catch (err) {
    console.warn("[LoRa] Could not initialize:", err.message);
    console.warn("[LoRa] Install serialport: npm install serialport");
  }
}

/**
 * Send a message out via LoRa radio
 */
function sendViaLoRa(message) {
  if (!loraPort || !loraPort.isOpen) return;
  const payload = JSON.stringify({
    content: message.content,
    sender: message.sender,
    category: message.category,
    priority: message.priority,
    ttl: message.ttl - 1,
  }) + "\n";

  loraPort.write(payload, (err) => {
    if (err) console.error("[LoRa] Write error:", err.message);
    else console.log("[LoRa] Message transmitted via radio");
  });
}

module.exports = { initLoRa, sendViaLoRa };
