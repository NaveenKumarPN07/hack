const http = require("http");
const Message = require("../models/Message");

let ioInstance = null;
const SYNC_INTERVAL = parseInt(process.env.SYNC_INTERVAL) || 30000;

/**
 * Get list of configured peer node URLs
 */
function getPeers() {
  return (process.env.PEERS || "").split(",").filter(Boolean);
}

/**
 * Forward a single message to all peer nodes (TTL-1 hop-by-hop)
 */
async function forwardTopeers(message) {
  const peers = getPeers();
  if (peers.length === 0) return;
  if (!message.ttl || message.ttl <= 0) return;

  const payload = JSON.stringify({
    messages: [
      {
        ...message,
        ttl: message.ttl - 1,
        hopCount: (message.hopCount || 0) + 1,
      },
    ],
  });

  for (const peer of peers) {
    try {
      await postJSON(`${peer}/api/messages/sync`, payload);
      console.log(`[Gossip] Forwarded to ${peer}`);
    } catch (err) {
      console.warn(`[Gossip] Failed to reach peer ${peer}: ${err.message}`);
    }
  }
}

/**
 * Periodic full sync — push recent messages to all peers every 30s
 */
async function syncWithPeers() {
  const peers = getPeers();
  if (peers.length === 0) return;

  try {
    // Get messages from the last 72 hours with TTL > 0
    const recent = await Message.find({ ttl: { $gt: 0 } })
      .sort({ createdAt: -1 })
      .limit(200)
      .lean();

    if (recent.length === 0) return;

    const payload = JSON.stringify({ messages: recent });

    for (const peer of peers) {
      try {
        const result = await postJSON(`${peer}/api/messages/sync`, payload);
        console.log(`[Gossip] Synced ${recent.length} msgs to ${peer} → saved: ${result.saved}, skipped: ${result.skipped}`);
      } catch (err) {
        console.warn(`[Gossip] Sync failed for peer ${peer}: ${err.message}`);
      }
    }
  } catch (err) {
    console.error("[Gossip] Sync error:", err.message);
  }
}

/**
 * Start the gossip engine — runs periodic sync
 */
function startGossipEngine(io) {
  ioInstance = io;
  const peers = getPeers();

  if (peers.length === 0) {
    console.log("[Gossip] No peers configured. Running as standalone node.");
    console.log("         Set PEERS=http://ip:3001,http://ip2:3001 in .env to enable mesh.");
  } else {
    console.log(`[Gossip] Mesh active. Peers: ${peers.join(", ")}`);
    console.log(`[Gossip] Syncing every ${SYNC_INTERVAL / 1000}s`);
  }

  // Run sync immediately on start, then on interval
  syncWithPeers();
  setInterval(syncWithPeers, SYNC_INTERVAL);
}

/**
 * Simple HTTP POST helper (no axios needed — pure Node.js)
 */
function postJSON(url, payload) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || 3001,
      path: urlObj.pathname,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(payload),
      },
      timeout: 5000,
    };

    const req = http.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          resolve({});
        }
      });
    });

    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Request timed out"));
    });

    req.write(payload);
    req.end();
  });
}

module.exports = { startGossipEngine, forwardTopeers, syncWithPeers };
