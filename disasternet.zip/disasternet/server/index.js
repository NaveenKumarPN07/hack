require("dotenv").config();
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const mongoose = require("mongoose");
const path = require("path");

const messageRoutes = require("./routes/messages");
const peerRoutes = require("./routes/peers");
const { startGossipEngine } = require("./utils/gossip");
const { initLoRa } = require("./utils/lora");

const app = express();
const server = http.createServer(app);

// Socket.IO - bind to all interfaces so LAN devices can connect
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

// Middleware
app.use(cors());
app.use(express.json({ limit: "1mb" }));

// Make io accessible in routes
app.set("io", io);

// API Routes
app.use("/api/messages", messageRoutes);
app.use("/api/peers", peerRoutes);

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    node: process.env.NODE_NAME || "DisasterNet Node",
    peers: (process.env.PEERS || "").split(",").filter(Boolean),
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// Serve React frontend in production
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../client/build")));
  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../client/build/index.html"));
  });
}

// Socket.IO connection handler
io.on("connection", (socket) => {
  console.log(`[Socket] Client connected: ${socket.id}`);

  socket.on("disconnect", () => {
    console.log(`[Socket] Client disconnected: ${socket.id}`);
  });
});

// Connect to MongoDB
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/disasternet";

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("[DB] MongoDB connected:", MONGO_URI);

    const PORT = process.env.PORT || 3001;
    server.listen(PORT, "0.0.0.0", () => {
      console.log(`\n🌐 DisasterNet Node running on port ${PORT}`);
      console.log(`   Local:   http://localhost:${PORT}`);
      console.log(`   Network: http://<your-ip>:${PORT}`);
      console.log(`   Health:  http://localhost:${PORT}/api/health\n`);

      // Start gossip engine after server is up
      startGossipEngine(io);

      // Initialize LoRa bridge if configured
      if (process.env.LORA_PORT) {
        initLoRa(io);
      }
    });
  })
  .catch((err) => {
    console.error("[DB] MongoDB connection error:", err.message);
    console.error("Make sure MongoDB is running: mongod --dbpath ./data");
    process.exit(1);
  });

module.exports = { io };
